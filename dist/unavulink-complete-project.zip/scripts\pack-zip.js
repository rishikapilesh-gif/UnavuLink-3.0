import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import archiver from 'archiver';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const publicDir = path.join(rootDir, 'public');
const distDir = path.join(rootDir, 'dist');
const zipFile = path.join(publicDir, 'unavulink-complete-project.zip');

if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

const output = fs.createWriteStream(zipFile);
const archive = archiver('zip', { zlib: { level: 9 } });

output.on('close', () => {
  console.log(`Zip archive created successfully: ${archive.pointer()} total bytes`);
  if (fs.existsSync(distDir)) {
    fs.copyFileSync(zipFile, path.join(distDir, 'unavulink-complete-project.zip'));
    console.log('Copied to dist/unavulink-complete-project.zip');
  }
});

archive.on('error', (err) => {
  throw err;
});

archive.pipe(output);

archive.glob('**/*', {
  cwd: rootDir,
  ignore: ['node_modules/**', '.git/**', 'dist/**', 'public/*.zip', '*.zip']
});

archive.finalize();
